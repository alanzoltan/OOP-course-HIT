#include <iostream>
#include "Rational.h"

Rational::Rational()
{
	nom = Polynomial();
	double* c = new double[1]; c[0] = 1;
	denom = Polynomial(c, 0);
}
Rational::Rational(const Polynomial& mone, const Polynomial& mehane)
{
	nom = mone;
	denom = mehane;
}
Polynomial Rational::getNom() const { return nom; }
Polynomial Rational::getDenom() const { return denom; }
Rational Rational::operator+(const Rational& other) const
{
	if (this->denom == other.denom)
	{
		Rational temp(this->nom + other.nom, this->denom);
		return temp;
	}
	Rational temp((this->nom * other.denom) + (other.nom * this->denom), this->denom * other.denom);
	return temp;
}
Rational Rational::operator-(const Rational& other) const
{
	if (this->denom == other.denom)
	{
		Rational temp(this->nom - other.nom, this->denom);
		return temp;
	}
	Rational temp((this->nom * other.denom) - (other.nom * this->denom), this->denom * other.denom);
	return temp;
}
Rational Rational::operator*(const Rational& other) const
{
	Rational temp(this->nom * other.nom, this->denom * other.denom);
	return temp;
}
Rational& Rational::operator=(const Rational& other)
{
	this->nom = other.nom;
	this->denom = other.denom;
	return *this;
}
ostream& operator<<(ostream& out, const Rational& other)
{
	out << "Numerator is " << other.nom << "---------------------" << endl;
	out << "Denominator is ";
	if (other.denom.getDegree(true) == 0) out << "Polynomial = 1" << endl;
	else other.denom.print();
	return out;
}
void Rational::print() const
{
	this->nom.print();
	cout << "-------------------" << endl;
	if (this->denom.getDegree(true) == 0) cout << "Polynomial = 1" << endl;
	else this->denom.print();
}
Rational::~Rational() {}

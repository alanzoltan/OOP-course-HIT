#include <iostream>
#include "Polynomial.h"

int Polynomial::MAXMAX = 0;

Polynomial::Polynomial()
{
	this->degree = 0;
	this->x = new double[1]; this->x[0] = 0;
}
Polynomial::Polynomial(int deg)
{
	this->degree = deg;
	this->x = new double[deg + 1];
	for (int i = 0; i <= deg; i++) this->x[i] = 0;
}
Polynomial::Polynomial(double coeffs[], int deg)
{
	this->degree = deg;
	this->x = new double[deg + 1];
	for (int i = 0; i <= deg; i++)
	{
		this->x[i] = coeffs[i];
		if (this->x[i] != 0 && std::fabsf(this->x[i]) < std::numeric_limits<float>::min())
			this->x[i] = 0;
	}
	for (int i = deg; i >= 0; i--)
	{
		if (this->x[i] != 0)
		{
			if (i > MAXMAX) MAXMAX = i;
			break;
		}
	}
}
const double Polynomial::getCoeff(int deg) const
{
	if (deg > this->degree || deg < 0) return -1234.12;
	return this->x[deg];
}
void Polynomial::setCoeff(const int deg, const double coeff)
{
	if (deg <= this->degree && deg > 0)
	{
		this->x[deg] = coeff;
		if (this->x[deg] != 0 && std::fabsf(this->x[deg]) < std::numeric_limits<float>::min())
			this->x[deg] = 0;
		int maxDeg = getDegree(true);
		if (maxDeg > MAXMAX) MAXMAX = maxDeg;
	}
}
const int Polynomial::getDegree(bool what) const
{
	if (!what) return this->degree;
	for (int i = this->degree; i >= 0; i--)
		if (this->x[i] != 0)
			return i;
	return 0;
}
int Polynomial::getMaxDegree()
{
	return MAXMAX;
}
Polynomial Polynomial::operator+(const Polynomial& other)const
{
	if (this->degree <= other.degree)
	{
		Polynomial temp(other.degree);
		for (int i = 0; i <= this->degree; i++)
		{
			temp.x[i] = this->x[i] + other.x[i];
			if (temp.x[i] != 0 && std::fabsf(temp.x[i]) < std::numeric_limits<float>::min())
				temp.x[i] = 0;
		}
		for (int i = this->degree + 1; i <= other.degree; i++)
		{
			temp.x[i] = other.x[i];
			if (temp.x[i] != 0 && std::fabsf(temp.x[i]) < std::numeric_limits<float>::min())
				temp.x[i] = 0;
		}
		return temp;
	}
	else
	{
		Polynomial temp(this->degree);
		for (int i = 0; i <= other.degree; i++)
		{
			temp.x[i] = this->x[i] + other.x[i];
			if (temp.x[i] != 0 && std::fabsf(temp.x[i]) < std::numeric_limits<float>::min())
				temp.x[i] = 0;
		}
		for (int i = other.degree + 1; i <= this->degree; i++)
		{
			temp.x[i] = this->x[i];
			if (temp.x[i] != 0 && std::fabsf(temp.x[i]) < std::numeric_limits<float>::min())
				temp.x[i] = 0;
		}
		return temp;
	}
}
Polynomial Polynomial::operator-(const Polynomial& other)const
{
	if (this->degree <= other.degree)
	{
		Polynomial temp(other.degree);
		for (int i = 0; i <= this->degree; i++)
		{
			temp.x[i] = this->x[i] - other.x[i];
			if (temp.x[i] != 0 && std::fabsf(temp.x[i]) < std::numeric_limits<float>::min())
				temp.x[i] = 0;
		}
		for (int i = this->degree + 1; i <= other.degree; i++)
		{
			temp.x[i] = -1 * other.x[i];
			if (temp.x[i] != 0 && std::fabsf(temp.x[i]) < std::numeric_limits<float>::min())
				temp.x[i] = 0;
		}
		return temp;
	}
	else
	{
		Polynomial temp(this->degree);
		for (int i = 0; i <= other.degree; i++)
		{
			temp.x[i] = this->x[i] - other.x[i];
			if (temp.x[i] != 0 && std::fabsf(temp.x[i]) < std::numeric_limits<float>::min())
				temp.x[i] = 0;
		}
		for (int i = other.degree + 1; i <= this->degree; i++)
		{
			temp.x[i] = this->x[i];
			if (temp.x[i] != 0 && std::fabsf(temp.x[i]) < std::numeric_limits<float>::min())
				temp.x[i] = 0;
		}
		return temp;
	}
}
Polynomial Polynomial::operator*(const Polynomial& other)const
{
	Polynomial temp(other.degree + this->degree);
	for (int i = 0; i <= other.degree; i++)
	{
		for (int j = 0; j <= this->degree; j++)
		{
			temp.x[i + j] = temp.x[i + j] + (other.x[i] * this->x[j]);
			if (temp.x[i + j] != 0 && std::fabsf(temp.x[i + j]) < std::numeric_limits<float>::min())
				temp.x[i + j] = 0;
			if (MAXMAX < i + j && temp.x[i + j] != 0)
				MAXMAX = i + j;
		}
	}
	return temp;
}
Polynomial operator*(double val, Polynomial& other)
{
	Polynomial temp(other.degree);
	for (int i = 0; i <= other.degree; i++)
	{
		temp.x[i] = val * other.x[i];
		if (temp.x[i] != 0 && std::fabsf(temp.x[i]) < std::numeric_limits<float>::min())
			temp.x[i] = 0;
	}
	return temp;
}
Polynomial& Polynomial::operator=(const Polynomial& other)
{
	delete[]x;
	if (this->degree < other.degree)
		this->degree = other.degree;
	this->x = new double[this->degree + 1];
	for (int i = 0; i <= this->degree; i++)
	{
		this->x[i] = other.x[i];
		if (this->x[i] != 0 && std::fabsf(this->x[i]) < std::numeric_limits<float>::min())
			this->x[i] = 0;
	}
	return *this;
}
bool Polynomial::operator==(const Polynomial& other) const
{
	int degLeft = this->getDegree(true), degRight = other.getDegree(true);
	if (degLeft == degRight)
		for (int i = 0; i <= degRight; i++)
			if (this->x[i] != other.x[i])
				return false;
	if (degLeft > degRight)
	{
		for (int i = 0; i <= degRight; i++)
			if (this->x[i] != other.x[i])
				return false;
		for (int i = degRight + 1; i <= degLeft; i++)
			if (this->x[i] != 0)
				return false;
	}
	if (degLeft < degRight)
	{
		for (int i = 0; i <= degLeft; i++)
			if (this->x[i] != other.x[i])
				return false;
		for (int i = degLeft + 1; i <= degRight; i++)
			if (other.x[i] != 0)
				return false;
	}
	return true;
}
ostream& operator<<(ostream& out, const Polynomial& other)
{
	out << "Polynomial = " << other.x[0];
	int maxDeg = other.getDegree(true);
	if (maxDeg != 0)
		for (int i = 1; i <= maxDeg; i++)
		{
			out << "+(";
			out << other.x[i];
			out << ")*x^";
			out << i;
		}
	out << endl;
	return out;
}
double Polynomial::operator[](const int index)
{
	return this->x[index];
}
void Polynomial::print() const
{
	cout << "Polynomial = " << this->x[0];
	int maxDeg = getDegree(true);
	if (maxDeg != 0)
		for (int i = 1; i <= maxDeg; i++)
			cout << "+(" << this->x[i] << ")*X^" << i;
	cout << endl;
}
Polynomial::~Polynomial() {}
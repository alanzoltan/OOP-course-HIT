#pragma once
#include <iostream>
#include "Polynomial.h"

class Rational
{
	friend ostream& operator<<(ostream& out, const Rational& other);
private:
	Polynomial nom, denom;
public:
	Rational();
	Rational(const Polynomial& mone, const Polynomial& mehane);
	Polynomial getNom() const;
	Polynomial getDenom() const;
	Rational operator+(const Rational& other) const;
	Rational operator-(const Rational& other) const;
	Rational operator*(const Rational& other) const;
	Rational& operator=(const Rational& other);
	void print() const;
	~Rational();
};
#pragma once
#include <iostream>
#include <cmath>
#include <limits>

using namespace std;

class Polynomial
{
	friend Polynomial operator*(double val, Polynomial& other);
	friend ostream& operator<<(ostream& out, const Polynomial& other);
private:
	int degree;
	double* x;
	static int MAXMAX;
public:
	Polynomial();
	Polynomial(int deg);
	Polynomial(double coeffs[], int deg);
	const double getCoeff(int deg) const;
	void setCoeff(const int deg, const double coeff);
	const int getDegree(bool what) const;
	static int getMaxDegree();
	Polynomial operator+(const Polynomial& other) const;
	Polynomial operator-(const Polynomial& other) const;
	Polynomial operator*(const Polynomial& other) const;
	Polynomial& operator=(const Polynomial& other);
	bool operator==(const Polynomial& other) const;
	double operator[](const int index);
	void print() const;
	~Polynomial();
};

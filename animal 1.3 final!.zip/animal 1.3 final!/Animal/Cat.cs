﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Media;
using System.Text;
using System.Threading.Tasks;
using WMPLib;
namespace Animal
{
    [Serializable]
    public class Cat : Mammal
    {
        public bool HasFurBall { get; set; }
        public bool IsHomeCat { get; set; }
        public Cat(string name, int age, double weight, string sex, string furColor, bool hasTail, string breed, bool hasFurBall, bool isHomeCat)
            : base(name, age, weight, sex, furColor, hasTail, breed)
        {
            HasFurBall = hasFurBall;
            IsHomeCat = isHomeCat;
            Subscription = 10;
        }
        public override void MakeSound()
        {
            SoundPlayer s = new SoundPlayer(@"C:\temp\animal 1.3 final!\Animal\bin\Debug\net6.0-windows\mixkit-angry-cartoon-kitty-meow-94.wav");
            s.Play();
        }
    }
}

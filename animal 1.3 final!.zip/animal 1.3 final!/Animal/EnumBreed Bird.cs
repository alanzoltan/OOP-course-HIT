﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Animal
{
    public enum EnumBreed_Bird
    {
        Raven,
        Lovebird,
        Pigeon,
        Polina,
        Parrot,
        Owl,
        Eagle
    }
}

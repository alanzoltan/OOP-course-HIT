﻿namespace Animal
{
    partial class AddCat
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            ClearButton = new Button();
            comboBoxFurColor = new ComboBox();
            comboBoxBreed = new ComboBox();
            label5 = new Label();
            label6 = new Label();
            isHomeCatCheckBox = new CheckBox();
            label1 = new Label();
            BallCheckBox = new CheckBox();
            AddButton = new Button();
            WeightTextBox = new TextBox();
            label3 = new Label();
            label4 = new Label();
            AgeTextBox = new TextBox();
            NameTextBox = new TextBox();
            label2 = new Label();
            NAME = new Label();
            ComboBoxSex = new ComboBox();
            label8 = new Label();
            label7 = new Label();
            checkBoxHasTail = new CheckBox();
            SuspendLayout();
            // 
            // ClearButton
            // 
            ClearButton.BackColor = SystemColors.ActiveCaption;
            ClearButton.Location = new Point(212, 322);
            ClearButton.Name = "ClearButton";
            ClearButton.Size = new Size(94, 29);
            ClearButton.TabIndex = 48;
            ClearButton.Text = "Clear";
            ClearButton.UseVisualStyleBackColor = false;
            ClearButton.Click += ClearButton_Click;
            // 
            // comboBoxFurColor
            // 
            comboBoxFurColor.FormattingEnabled = true;
            comboBoxFurColor.Location = new Point(146, 201);
            comboBoxFurColor.Name = "comboBoxFurColor";
            comboBoxFurColor.Size = new Size(151, 28);
            comboBoxFurColor.TabIndex = 47;
            // 
            // comboBoxBreed
            // 
            comboBoxBreed.FormattingEnabled = true;
            comboBoxBreed.Location = new Point(146, 133);
            comboBoxBreed.Name = "comboBoxBreed";
            comboBoxBreed.Size = new Size(151, 28);
            comboBoxBreed.TabIndex = 46;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(39, 201);
            label5.Name = "label5";
            label5.Size = new Size(69, 20);
            label5.TabIndex = 45;
            label5.Text = "Fur Color";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(39, 136);
            label6.Name = "label6";
            label6.Size = new Size(48, 20);
            label6.TabIndex = 44;
            label6.Text = "Breed";
            // 
            // isHomeCatCheckBox
            // 
            isHomeCatCheckBox.AutoSize = true;
            isHomeCatCheckBox.Location = new Point(146, 284);
            isHomeCatCheckBox.Name = "isHomeCatCheckBox";
            isHomeCatCheckBox.Size = new Size(18, 17);
            isHomeCatCheckBox.TabIndex = 43;
            isHomeCatCheckBox.UseVisualStyleBackColor = true;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(39, 281);
            label1.Name = "label1";
            label1.Size = new Size(82, 20);
            label1.TabIndex = 42;
            label1.Text = "IsHomeCat";
            // 
            // BallCheckBox
            // 
            BallCheckBox.AutoSize = true;
            BallCheckBox.Location = new Point(146, 252);
            BallCheckBox.Name = "BallCheckBox";
            BallCheckBox.Size = new Size(18, 17);
            BallCheckBox.TabIndex = 41;
            BallCheckBox.UseVisualStyleBackColor = true;
            // 
            // AddButton
            // 
            AddButton.BackColor = SystemColors.ActiveCaption;
            AddButton.Location = new Point(61, 322);
            AddButton.Name = "AddButton";
            AddButton.Size = new Size(94, 29);
            AddButton.TabIndex = 40;
            AddButton.Text = "Add";
            AddButton.UseVisualStyleBackColor = false;
            AddButton.Click += AddButton_Click;
            // 
            // WeightTextBox
            // 
            WeightTextBox.Location = new Point(146, 100);
            WeightTextBox.Name = "WeightTextBox";
            WeightTextBox.Size = new Size(125, 27);
            WeightTextBox.TabIndex = 39;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(39, 249);
            label3.Name = "label3";
            label3.Size = new Size(63, 20);
            label3.TabIndex = 38;
            label3.Text = "Has Ball";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(39, 100);
            label4.Name = "label4";
            label4.Size = new Size(56, 20);
            label4.TabIndex = 37;
            label4.Text = "Weight";
            // 
            // AgeTextBox
            // 
            AgeTextBox.Location = new Point(146, 63);
            AgeTextBox.Name = "AgeTextBox";
            AgeTextBox.Size = new Size(125, 27);
            AgeTextBox.TabIndex = 36;
            // 
            // NameTextBox
            // 
            NameTextBox.Location = new Point(146, 27);
            NameTextBox.Name = "NameTextBox";
            NameTextBox.Size = new Size(125, 27);
            NameTextBox.TabIndex = 35;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(39, 63);
            label2.Name = "label2";
            label2.Size = new Size(36, 20);
            label2.TabIndex = 34;
            label2.Text = "Age";
            // 
            // NAME
            // 
            NAME.AutoSize = true;
            NAME.Location = new Point(39, 27);
            NAME.Name = "NAME";
            NAME.Size = new Size(49, 20);
            NAME.TabIndex = 33;
            NAME.Text = "Name";
            // 
            // ComboBoxSex
            // 
            ComboBoxSex.FormattingEnabled = true;
            ComboBoxSex.Location = new Point(146, 167);
            ComboBoxSex.Name = "ComboBoxSex";
            ComboBoxSex.Size = new Size(151, 28);
            ComboBoxSex.TabIndex = 50;
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Location = new Point(39, 170);
            label8.Name = "label8";
            label8.Size = new Size(32, 20);
            label8.TabIndex = 49;
            label8.Text = "Sex";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Location = new Point(195, 262);
            label7.Name = "label7";
            label7.Size = new Size(60, 20);
            label7.TabIndex = 51;
            label7.Text = "Has Tail";
            // 
            // checkBoxHasTail
            // 
            checkBoxHasTail.AutoSize = true;
            checkBoxHasTail.Location = new Point(279, 265);
            checkBoxHasTail.Name = "checkBoxHasTail";
            checkBoxHasTail.Size = new Size(18, 17);
            checkBoxHasTail.TabIndex = 52;
            checkBoxHasTail.UseVisualStyleBackColor = true;
            // 
            // AddCat
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            Controls.Add(checkBoxHasTail);
            Controls.Add(label7);
            Controls.Add(ComboBoxSex);
            Controls.Add(label8);
            Controls.Add(ClearButton);
            Controls.Add(comboBoxFurColor);
            Controls.Add(comboBoxBreed);
            Controls.Add(label5);
            Controls.Add(label6);
            Controls.Add(isHomeCatCheckBox);
            Controls.Add(label1);
            Controls.Add(BallCheckBox);
            Controls.Add(AddButton);
            Controls.Add(WeightTextBox);
            Controls.Add(label3);
            Controls.Add(label4);
            Controls.Add(AgeTextBox);
            Controls.Add(NameTextBox);
            Controls.Add(label2);
            Controls.Add(NAME);
            Name = "AddCat";
            Size = new Size(381, 442);
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button ClearButton;
        private ComboBox comboBoxFurColor;
        private ComboBox comboBoxBreed;
        private Label label5;
        private Label label6;
        private CheckBox isHomeCatCheckBox;
        private Label label1;
        private CheckBox BallCheckBox;
        private Button AddButton;
        private TextBox WeightTextBox;
        private Label label3;
        private Label label4;
        private TextBox AgeTextBox;
        private TextBox NameTextBox;
        private Label label2;
        private Label NAME;
        private ComboBox ComboBoxSex;
        private Label label8;
        private Label label7;
        private CheckBox checkBoxHasTail;
    }
}

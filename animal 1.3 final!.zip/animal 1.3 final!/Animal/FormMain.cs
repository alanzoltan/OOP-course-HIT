using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.IO;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Formatters.Binary;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace Animal
{
    public partial class FormMain : Form
    {
        BindingList<Dog> dogs;
        BindingList<Cat> cats;
        public FormMain()
        {
            InitializeComponent();
            comboBoxKind.Items.Add("Dog");
            comboBoxKind.Items.Add("Cat");
            dogs = AnimalsManager.GetSpecificAnimals<Dog>();
            cats = AnimalsManager.GetSpecificAnimals<Cat>();
            //this.FormClosing += new FormClosingEventHandler(AnimalsManager.SaveAnimals);
        }


        private void ComboBoxKind_SelectedIndexChanged(object sender, EventArgs e)
        {
            AddAnimal.Controls.Clear();
            if (comboBoxKind.SelectedItem.ToString() == "Dog")
            {
                dogs = AnimalsManager.GetSpecificAnimals<Dog>();//����� �����
                dataGridViewAnimal.DataSource = dogs;
                AddAnimal.Controls.Add(new AddDog(dogs));
                AdjustColumnOrder();
            }
            else if (comboBoxKind.SelectedItem.ToString() == "Cat")
            {
                cats = AnimalsManager.GetSpecificAnimals<Cat>();
                dataGridViewAnimal.DataSource = cats;
                AddAnimal.Controls.Add(new AddCat(cats));
                AdjustColumnOrder();
            }
        }


        private void buttonDelete_Click(object sender, EventArgs e)
        {
            if (comboBoxKind.SelectedItem.ToString() == "Dog")
            {
                if (dataGridViewAnimal.SelectedRows.Count > 0)
                {
                    DataGridViewSelectedRowCollection selectedRows = dataGridViewAnimal.SelectedRows;
                    foreach (DataGridViewRow row in selectedRows)
                    {
                        int rowIndex = row.Index;
                        dogs[rowIndex].UpdatePayment();
                        Animal.allMoney += dogs[rowIndex].Payment;
                        dogs.RemoveAt(rowIndex);
                        AnimalsManager.UpdateSpecificAnimal<Dog>(dogs);
                        AnimalsManager.SaveAnimalsNotEvent();
                    }
                }

            }
            else if (comboBoxKind.SelectedItem.ToString() == "Cat")
            {
                if (dataGridViewAnimal.SelectedRows.Count > 0)
                {
                    DataGridViewSelectedRowCollection selectedRows = dataGridViewAnimal.SelectedRows;
                    foreach (DataGridViewRow row in selectedRows)
                    {
                        int rowIndex = row.Index;
                        cats[rowIndex].UpdatePayment();
                        Animal.allMoney += cats[rowIndex].Payment;
                        cats.RemoveAt(rowIndex);
                        AnimalsManager.UpdateSpecificAnimal<Cat>(cats);
                        AnimalsManager.SaveAnimalsNotEvent();
                    }
                }
            }
        }
        private void AdjustColumnOrder()
        {
            dataGridViewAnimal.Columns["SurgeryBrain"].Visible = false;
            dataGridViewAnimal.Columns["SurgeryLungs"].Visible = false;
            dataGridViewAnimal.Columns["SurgeryHeart"].Visible = false;
            dataGridViewAnimal.Columns["SurgeryPaws"].Visible = false;
            dataGridViewAnimal.Columns["SurgeryFlea"].Visible = false;
            dataGridViewAnimal.Columns["SurgeryAllergy"].Visible = false;
            dataGridViewAnimal.Columns["Payment"].Visible = false;
            dataGridViewAnimal.Columns["Subscription"].Visible = false;
            dataGridViewAnimal.Columns["Name"].DisplayIndex = 0;
            dataGridViewAnimal.Columns["Age"].DisplayIndex = 1;
            dataGridViewAnimal.Columns["Weight"].DisplayIndex = 2;
            dataGridViewAnimal.Columns["Sex"].DisplayIndex = 3;
            dataGridViewAnimal.Columns["Breed"].DisplayIndex = 4;
            dataGridViewAnimal.Columns["FurColor"].DisplayIndex = 5;
            dataGridViewAnimal.Columns["HasTail"].DisplayIndex = 6;
            if (comboBoxKind.SelectedItem.ToString() == "Cat")
            {
                dataGridViewAnimal.Columns["HasFurBall"].DisplayIndex = 7;
                dataGridViewAnimal.Columns["IsHomeCat"].DisplayIndex = 8;
            }
            else if (comboBoxKind.SelectedItem.ToString() == "Dog")
            {
                dataGridViewAnimal.Columns["HasFleaCollar"].DisplayIndex = 7;
            }
        }
    }
}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Animal
{
    public enum EnumColors
    {
        Black,
        White,
        Gold,
        Gray,
        Brown,
        Auburn,
        Multiple
    }
}

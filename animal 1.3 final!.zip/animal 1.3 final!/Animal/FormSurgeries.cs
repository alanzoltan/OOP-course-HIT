﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Animal
{
    public partial class FormSurgeries : Form
    {
        BindingList<Mammal> mammals;
        public FormSurgeries()
        {
            InitializeComponent();
            mammals = AnimalsManager.GetSpecificAnimals<Mammal>();
            dataGridView1.DataSource = mammals;
            AdjustColumnOrder();
        }
        private void AdjustColumnOrder()
        {
            dataGridView1.Columns["Payment"].Visible = false;
            dataGridView1.Columns["Subscription"].Visible = false;
            dataGridView1.Columns["Name"].DisplayIndex = 0;
            dataGridView1.Columns["Age"].DisplayIndex = 1;
            dataGridView1.Columns["Weight"].DisplayIndex = 2;
            dataGridView1.Columns["Sex"].DisplayIndex = 3;
            dataGridView1.Columns["Breed"].DisplayIndex = 4;
            dataGridView1.Columns["FurColor"].Visible = false;
            dataGridView1.Columns["HasTail"].Visible = false;
            dataGridView1.Columns["SurgeryBrain"].Visible = false;
            dataGridView1.Columns["SurgeryHeart"].Visible = false;
            dataGridView1.Columns["SurgeryLungs"].Visible = false;
            dataGridView1.Columns["SurgeryPaws"].Visible = false;
            dataGridView1.Columns["SurgeryFlea"].Visible = false;
            dataGridView1.Columns["SurgeryAllergy"].Visible = false;
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (dataGridView1.SelectedRows.Count > 0)
            {
                panel1.Controls.Clear();
                int rowIndex = e.RowIndex;
                panel1.Controls.Add(new MammalSurgery(mammals[rowIndex]));
            }
        }
    }
}

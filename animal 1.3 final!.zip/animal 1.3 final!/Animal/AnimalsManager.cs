﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Animal
{
    public class AnimalsManager
    {
        private static BindingList<Animal> animals;//obj collection, כדי שנוכל להשתמש בזה לכל החיות 
        static AnimalsManager()
        {
            animals = Seri.Load();
        }
        public static void SaveAnimals(object sender,FormClosingEventArgs e)
        {
            Seri.Save(animals);
        }
        public static void SaveAnimalsNotEvent()
        {
            Seri.Save(animals);
        }
        public static BindingList<Animal> GetAnimals()
        {
            return animals;
        }
        public static void AddAnimal(Animal animal)
        {
            animals.Add(animal);
        }
        public static BindingList<T> GetSpecificAnimals<T>() where T:Animal
        {
            BindingList<T> specificAnimals = new BindingList<T>();
            foreach(Animal animal in animals)
            {
                if (animal is T)
                {
                    specificAnimals.Add(animal as T);
                }
            }
            return specificAnimals;
        }
        public static void UpdateSpecificAnimal<T>(BindingList<T> updated) where T :Animal
        {
            BindingList<T> specificAnimals = new BindingList<T>();
            BindingList<Animal> new_animals = new BindingList<Animal>();
            foreach (Animal animal in animals)
            {
                if(animal is not T)
                {
                    new_animals.Add(animal);
                }
            }
            foreach (T animal in updated)
            {
                new_animals.Add(animal);
            }
            animals = new_animals;
        }
    }
}

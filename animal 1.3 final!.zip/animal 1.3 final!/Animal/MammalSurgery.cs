﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Animal
{
    public partial class MammalSurgery : UserControl
    {
        Mammal mammal;
        public MammalSurgery(Mammal m)
        {
            InitializeComponent();
            mammal = m;
            labelName.Text = m.Name;
            labelAge.Text = m.Age.ToString();
            labelWeight.Text = m.Weight.ToString();
            labelSex.Text = m.Sex.ToString();
            labelBreed.Text = m.Breed.ToString();
            labelBrain.Text = m.SurgeryBrain.ToString();
            labelHeart.Text = m.SurgeryHeart.ToString();
            labelLungs.Text = m.SurgeryLungs.ToString();
            labelPaws.Text = m.SurgeryPaws.ToString();
            labelFleas.Text = m.SurgeryFlea.ToString();
            labelAllergy.Text = m.SurgeryAllergy.ToString();
        }

        private void buttonSurgery_Click(object sender, EventArgs e)
        {
            MessageBoxSurgery messageBoxSurgery = new MessageBoxSurgery(mammal);
            messageBoxSurgery.ShowDialog();

        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Animal
{
    [Serializable]
    
    public abstract class Animal
    {
        public string Name { get; set; }
        public int Age { get; set; }
        public double Weight { get; set; }
        public string Sex { get; set; }
        public int Payment { get; set; }
        public static int allMoney { get; set; } = 0;
        public int Subscription { get; set; }
        protected Animal(string name,int age,double weight,string sex)
        {
            Name = name;
            Age = age;
            Weight = weight;
            Sex = sex;
            Subscription = 0;
            Payment = Subscription;
        }
        public abstract void MakeSound();
    }
    
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Runtime.Serialization.Formatters.Binary;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Xml.Linq;

namespace Animal
{
    public class Seri
    {
        public static void Save(BindingList<Animal> animals)
        {
            if (!(File.Exists("animals.dat")))
            {
                using (FileStream fs = new FileStream("animals.dat", FileMode.Create))
                {
                    BinaryFormatter formatter = new BinaryFormatter();
                    formatter.Serialize(fs, animals);
                    fs.Flush();
                    fs.Close();
                    fs.Dispose();
                }
            }
            else
            {
                using (FileStream fs = File.OpenWrite("animals.dat"))
                {
                    BinaryFormatter formatter = new BinaryFormatter();
                    formatter.Serialize(fs, animals);
                    fs.Flush();
                    fs.Close();
                    fs.Dispose();
                }
            }
            if(!(File.Exists("allMoney.dat")))
            {
                using (FileStream fs1 = new FileStream("allMoney.dat", FileMode.Create))
                {
                    BinaryFormatter formatter1 = new BinaryFormatter();
                    formatter1.Serialize(fs1, Animal.allMoney);
                    fs1.Flush();
                    fs1.Close();
                    fs1.Dispose();
                }
            }
            else
            {
                using (FileStream fs1 = File.OpenWrite("allMoney.dat"))
                {
                    BinaryFormatter formatter1 = new BinaryFormatter();
                    formatter1.Serialize(fs1, Animal.allMoney);
                    fs1.Flush();
                    fs1.Close();
                    fs1.Dispose();
                }
            }
        }
        public static BindingList<Animal> Load()
        {
            BindingList<Animal> animals;
            try
            {
                FileStream fs = new FileStream("animals.dat", FileMode.Open);
                BinaryFormatter formatter = new BinaryFormatter();
                animals = (BindingList<Animal>)formatter.Deserialize(fs);
                fs.Flush();
                fs.Close();
                fs.Dispose();
            }
            catch (Exception ex)
            {
                animals = new BindingList<Animal>();
            }
            return animals;
        }
        public static void LoadMoney()
        {
            try
            {
                FileStream fs1 = new FileStream("allMoney.dat", FileMode.Open);
                BinaryFormatter formatter1 = new BinaryFormatter();
                Animal.allMoney = (int)formatter1.Deserialize(fs1);
                fs1.Flush();
                fs1.Close();
                fs1.Dispose();
            }
            catch (Exception ex)
            {
                Animal.allMoney = 0;
            }
        }
        public static void SaveMoney()
        {
            if (!(File.Exists("allMoney.dat")))
            {
                using (FileStream fs1 = new FileStream("allMoney.dat", FileMode.Create))
                {
                    BinaryFormatter formatter1 = new BinaryFormatter();
                    formatter1.Serialize(fs1, Animal.allMoney);
                    fs1.Flush();
                    fs1.Close();
                    fs1.Dispose();
                }
            }
            else
            {
                using (FileStream fs1 = File.OpenWrite("allMoney.dat"))
                {
                    BinaryFormatter formatter1 = new BinaryFormatter();
                    formatter1.Serialize(fs1, Animal.allMoney);
                    fs1.Flush();
                    fs1.Close();
                    fs1.Dispose();
                }
            }
        }
    }
}

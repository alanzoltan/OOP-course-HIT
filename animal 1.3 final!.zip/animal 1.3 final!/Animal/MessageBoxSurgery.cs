﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Animal
{
    public partial class MessageBoxSurgery : Form
    {
        Mammal mammal;
        public MessageBoxSurgery(Mammal m)
        {
            InitializeComponent();
            mammal = m;
        }

        private void ButtonSelect_Click(object sender, EventArgs e)
        {
            if (ButtonAllergy.Checked)
            {
                mammal.SurgeryAllergy++;
                AnimalsManager.SaveAnimalsNotEvent();
                MessageBox.Show("You succesfully performed allergy treatment");
                Close();
            }
            if (ButtonBrain.Checked)
            {
                mammal.SurgeryBrain++;
                AnimalsManager.SaveAnimalsNotEvent();
                MessageBox.Show("You succesfully performed brain surgery");
                Close();
            }
            if (ButtonPaws.Checked)
            {
                mammal.SurgeryPaws++;
                AnimalsManager.SaveAnimalsNotEvent();
                MessageBox.Show("You succesfully performed paws surgery");
                Close();
            }
            if (ButtonHeart.Checked)
            {
                mammal.SurgeryHeart++;
                AnimalsManager.SaveAnimalsNotEvent();
                MessageBox.Show("You succesfully performed heart surgery");
                Close();
            }
            if (ButtonLungs.Checked)
            {
                mammal.SurgeryLungs++;
                AnimalsManager.SaveAnimalsNotEvent();
                MessageBox.Show("You succesfully performed lungs surgery");
                Close();
            }
            if (ButtonFleas.Checked)
            {
                mammal.SurgeryFlea++;
                AnimalsManager.SaveAnimalsNotEvent();
                MessageBox.Show("You succesfully performed flea treatment");
                Close();
            }
        }
    }
}

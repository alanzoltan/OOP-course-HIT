﻿namespace Animal
{
    partial class MammalSurgery
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            labelName = new Label();
            buttonSurgery = new Button();
            labelAge = new Label();
            labelWeight = new Label();
            labelSex = new Label();
            label1 = new Label();
            label5 = new Label();
            labelBreed = new Label();
            label2 = new Label();
            label4 = new Label();
            label6 = new Label();
            label7 = new Label();
            label8 = new Label();
            label9 = new Label();
            label10 = new Label();
            labelHeart = new Label();
            labelBrain = new Label();
            labelLungs = new Label();
            labelFleas = new Label();
            labelAllergy = new Label();
            labelPaws = new Label();
            SuspendLayout();
            // 
            // labelName
            // 
            labelName.AutoSize = true;
            labelName.Font = new Font("Segoe UI", 13.8F, FontStyle.Bold | FontStyle.Underline, GraphicsUnit.Point);
            labelName.ForeColor = Color.Blue;
            labelName.Location = new Point(100, 17);
            labelName.Name = "labelName";
            labelName.Size = new Size(97, 31);
            labelName.TabIndex = 0;
            labelName.Text = "*Name*";
            // 
            // buttonSurgery
            // 
            buttonSurgery.BackColor = SystemColors.ActiveCaption;
            buttonSurgery.ForeColor = Color.Black;
            buttonSurgery.Location = new Point(87, 345);
            buttonSurgery.Name = "buttonSurgery";
            buttonSurgery.Size = new Size(94, 29);
            buttonSurgery.TabIndex = 1;
            buttonSurgery.Text = "Surgery?";
            buttonSurgery.UseVisualStyleBackColor = false;
            buttonSurgery.Click += buttonSurgery_Click;
            // 
            // labelAge
            // 
            labelAge.AutoSize = true;
            labelAge.Location = new Point(19, 61);
            labelAge.Name = "labelAge";
            labelAge.Size = new Size(48, 20);
            labelAge.TabIndex = 2;
            labelAge.Text = "*Age*";
            // 
            // labelWeight
            // 
            labelWeight.AutoSize = true;
            labelWeight.Location = new Point(148, 61);
            labelWeight.Name = "labelWeight";
            labelWeight.Size = new Size(68, 20);
            labelWeight.TabIndex = 3;
            labelWeight.Text = "*Weight*";
            // 
            // labelSex
            // 
            labelSex.AutoSize = true;
            labelSex.Location = new Point(189, 102);
            labelSex.Name = "labelSex";
            labelSex.Size = new Size(44, 20);
            labelSex.TabIndex = 4;
            labelSex.Text = "*Sex*";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(78, 61);
            label1.Name = "label1";
            label1.Size = new Size(33, 20);
            label1.TabIndex = 5;
            label1.Text = "Old";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(225, 61);
            label5.Name = "label5";
            label5.Size = new Size(27, 20);
            label5.TabIndex = 8;
            label5.Text = "Kg";
            // 
            // labelBreed
            // 
            labelBreed.AutoSize = true;
            labelBreed.Location = new Point(19, 102);
            labelBreed.Name = "labelBreed";
            labelBreed.Size = new Size(60, 20);
            labelBreed.TabIndex = 10;
            labelBreed.Text = "*Breed*";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI", 13.8F, FontStyle.Bold | FontStyle.Underline, GraphicsUnit.Point);
            label2.ForeColor = Color.Blue;
            label2.Location = new Point(48, 131);
            label2.Name = "label2";
            label2.Size = new Size(185, 31);
            label2.TabIndex = 11;
            label2.Text = "Surgeries made:";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.ForeColor = Color.Blue;
            label4.Location = new Point(33, 175);
            label4.Name = "label4";
            label4.Size = new Size(46, 20);
            label4.TabIndex = 12;
            label4.Text = "Heart";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.ForeColor = Color.Blue;
            label6.Location = new Point(118, 175);
            label6.Name = "label6";
            label6.Size = new Size(43, 20);
            label6.TabIndex = 13;
            label6.Text = "Brain";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.ForeColor = Color.Blue;
            label7.Location = new Point(196, 175);
            label7.Name = "label7";
            label7.Size = new Size(47, 20);
            label7.TabIndex = 14;
            label7.Text = "Lungs";
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.ForeColor = Color.Blue;
            label8.Location = new Point(33, 255);
            label8.Name = "label8";
            label8.Size = new Size(42, 20);
            label8.TabIndex = 15;
            label8.Text = "Fleas";
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.ForeColor = Color.Blue;
            label9.Location = new Point(118, 255);
            label9.Name = "label9";
            label9.Size = new Size(56, 20);
            label9.TabIndex = 16;
            label9.Text = "Allergy";
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.ForeColor = Color.Blue;
            label10.Location = new Point(202, 255);
            label10.Name = "label10";
            label10.Size = new Size(41, 20);
            label10.TabIndex = 17;
            label10.Text = "Paws";
            // 
            // labelHeart
            // 
            labelHeart.AutoSize = true;
            labelHeart.Location = new Point(29, 213);
            labelHeart.Name = "labelHeart";
            labelHeart.Size = new Size(50, 20);
            labelHeart.TabIndex = 18;
            labelHeart.Text = "*Sum*";
            // 
            // labelBrain
            // 
            labelBrain.AutoSize = true;
            labelBrain.Location = new Point(118, 213);
            labelBrain.Name = "labelBrain";
            labelBrain.Size = new Size(50, 20);
            labelBrain.TabIndex = 19;
            labelBrain.Text = "*Sum*";
            // 
            // labelLungs
            // 
            labelLungs.AutoSize = true;
            labelLungs.Location = new Point(196, 215);
            labelLungs.Name = "labelLungs";
            labelLungs.Size = new Size(50, 20);
            labelLungs.TabIndex = 20;
            labelLungs.Text = "*Sum*";
            // 
            // labelFleas
            // 
            labelFleas.AutoSize = true;
            labelFleas.Location = new Point(29, 290);
            labelFleas.Name = "labelFleas";
            labelFleas.Size = new Size(50, 20);
            labelFleas.TabIndex = 21;
            labelFleas.Text = "*Sum*";
            // 
            // labelAllergy
            // 
            labelAllergy.AutoSize = true;
            labelAllergy.Location = new Point(118, 290);
            labelAllergy.Name = "labelAllergy";
            labelAllergy.Size = new Size(50, 20);
            labelAllergy.TabIndex = 22;
            labelAllergy.Text = "*Sum*";
            // 
            // labelPaws
            // 
            labelPaws.AutoSize = true;
            labelPaws.Location = new Point(202, 290);
            labelPaws.Name = "labelPaws";
            labelPaws.Size = new Size(50, 20);
            labelPaws.TabIndex = 23;
            labelPaws.Text = "*Sum*";
            // 
            // MammalSurgery
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.ButtonHighlight;
            Controls.Add(labelPaws);
            Controls.Add(labelAllergy);
            Controls.Add(labelFleas);
            Controls.Add(labelLungs);
            Controls.Add(labelBrain);
            Controls.Add(labelHeart);
            Controls.Add(label10);
            Controls.Add(label9);
            Controls.Add(label8);
            Controls.Add(label7);
            Controls.Add(label6);
            Controls.Add(label4);
            Controls.Add(label2);
            Controls.Add(labelBreed);
            Controls.Add(label5);
            Controls.Add(label1);
            Controls.Add(labelSex);
            Controls.Add(labelWeight);
            Controls.Add(labelAge);
            Controls.Add(buttonSurgery);
            Controls.Add(labelName);
            Name = "MammalSurgery";
            Size = new Size(288, 393);
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label labelName;
        private Button buttonSurgery;
        private Label labelAge;
        private Label labelWeight;
        private Label labelSex;
        private Label label1;
        private Label label5;
        private Label labelBreed;
        private Label label2;
        private Label label4;
        private Label label6;
        private Label label7;
        private Label label8;
        private Label label9;
        private Label label10;
        private Label labelHeart;
        private Label labelBrain;
        private Label labelLungs;
        private Label labelFleas;
        private Label labelAllergy;
        private Label labelPaws;
    }
}

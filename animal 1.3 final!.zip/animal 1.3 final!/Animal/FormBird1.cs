﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Animal
{
    public partial class FormBird1 : Form
    {
        BindingList<Bird> birdsList;
        public FormBird1()
        {
            InitializeComponent();
            birdsList = AnimalsManager.GetSpecificAnimals<Bird>();
            //this.FormClosing += new FormClosingEventHandler(AnimalsManager.SaveAnimals);
            comboBoxSex.Items.Add("Male");
            comboBoxSex.Items.Add("Female");
            comboBoxBreed.DataSource = Enum.GetValues(typeof(EnumBreed_Bird));
            comboBoxColor.DataSource = Enum.GetValues(typeof(EnumColorBirds));
            dataGridView1.DataSource = birdsList;
            AdjustColumnOrder();
        }

        private void buttonAdd_Click(object sender, EventArgs e)
        {
            if (IsValidForm())
            {
                string name = textBoxName.Text;
                int age = int.Parse(textBoxAge.Text);
                double weight = Double.Parse(textBoxWeight.Text);
                string sex = comboBoxSex.SelectedItem.ToString();
                string Color = comboBoxColor.SelectedItem.ToString();
                string breed = comboBoxBreed.SelectedItem.ToString();
                bool homebird = checkBoxHomebird.Checked;
                bool cutWings = checkBoxCutWings.Checked;
                Bird bird = new Bird(name, age, weight, sex, homebird, cutWings, Color, breed);
                AnimalsManager.AddAnimal(bird);
                birdsList.Add(bird);
                ClearForm();
                bird.MakeSound();
                AnimalsManager.UpdateSpecificAnimal<Bird>(birdsList);
                AnimalsManager.SaveAnimalsNotEvent();
            }
        }

        private void buttonClear_Click(object sender, EventArgs e)
        {
            ClearForm();
        }

        private void buttonDelete_Click(object sender, EventArgs e)
        {
            if (dataGridView1.SelectedRows.Count > 0)
            {
                DataGridViewSelectedRowCollection selectedRows = dataGridView1.SelectedRows;
                foreach (DataGridViewRow row in selectedRows)
                {
                    int rowIndex = row.Index;
                    Animal.allMoney += birdsList[rowIndex].Payment;
                    birdsList.RemoveAt(rowIndex);
                    AnimalsManager.UpdateSpecificAnimal<Bird>(birdsList);
                    AnimalsManager.SaveAnimalsNotEvent();
                }
            }
        }
        private bool IsValidForm()
        {
            int age, weight;
            if (Int32.TryParse(textBoxAge.Text, out age) != true) return false;
            if (Int32.TryParse(textBoxWeight.Text, out weight) != true) return false;
            if (textBoxName == null) return false;
            return true;
        }
        private void ClearForm()
        {
            textBoxName.Clear();
            textBoxAge.Clear();
            textBoxWeight.Clear();
            checkBoxCutWings.Checked = false;
            checkBoxHomebird.Checked = false;
            comboBoxBreed.ResetText();
            comboBoxColor.ResetText();
            comboBoxSex.ResetText();
        }
        private void AdjustColumnOrder()
        {
            dataGridView1.Columns["Payment"].Visible = false;
            dataGridView1.Columns["Subscription"].Visible = false;
            dataGridView1.Columns["Name"].DisplayIndex = 0;
            dataGridView1.Columns["Age"].DisplayIndex = 1;
            dataGridView1.Columns["Weight"].DisplayIndex = 2;
            dataGridView1.Columns["Sex"].DisplayIndex = 3;
            dataGridView1.Columns["Breed"].DisplayIndex = 4;
            dataGridView1.Columns["Color"].DisplayIndex = 5;
            dataGridView1.Columns["Homebird"].DisplayIndex = 6;
            dataGridView1.Columns["CutWings"].DisplayIndex = 7;
        }
    }
}

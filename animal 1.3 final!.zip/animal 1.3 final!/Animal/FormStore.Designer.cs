﻿namespace Animal
{
    partial class FormStore
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormStore));
            panel1 = new Panel();
            label12 = new Label();
            label11 = new Label();
            label10 = new Label();
            label9 = new Label();
            label8 = new Label();
            label7 = new Label();
            label6 = new Label();
            label5 = new Label();
            price = new Label();
            panel2 = new Panel();
            pictureBox1 = new PictureBox();
            panel3 = new Panel();
            label14 = new Label();
            label13 = new Label();
            pictureBox2 = new PictureBox();
            pictureBox3 = new PictureBox();
            pictureBox4 = new PictureBox();
            pictureBox5 = new PictureBox();
            BuyDrugs = new Button();
            BuyEquipment = new Button();
            BuyGrooming = new Button();
            BuyFurniture = new Button();
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            label4 = new Label();
            comboBoxDrugs = new ComboBox();
            comboBoxGrooming = new ComboBox();
            panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            panel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox4).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox5).BeginInit();
            SuspendLayout();
            // 
            // panel1
            // 
            panel1.BackColor = SystemColors.ActiveCaption;
            panel1.Controls.Add(label12);
            panel1.Controls.Add(label11);
            panel1.Controls.Add(label10);
            panel1.Controls.Add(label9);
            panel1.Controls.Add(label8);
            panel1.Controls.Add(label7);
            panel1.Controls.Add(label6);
            panel1.Controls.Add(label5);
            panel1.Controls.Add(price);
            panel1.Controls.Add(panel2);
            panel1.Location = new Point(-4, -3);
            panel1.Name = "panel1";
            panel1.Size = new Size(208, 576);
            panel1.TabIndex = 0;
            // 
            // label12
            // 
            label12.AutoSize = true;
            label12.Location = new Point(140, 301);
            label12.Name = "label12";
            label12.Size = new Size(33, 20);
            label12.TabIndex = 18;
            label12.Text = "500";
            // 
            // label11
            // 
            label11.AutoSize = true;
            label11.Location = new Point(140, 260);
            label11.Name = "label11";
            label11.Size = new Size(25, 20);
            label11.TabIndex = 17;
            label11.Text = "20";
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.Location = new Point(140, 224);
            label10.Name = "label10";
            label10.Size = new Size(25, 20);
            label10.TabIndex = 16;
            label10.Text = "15";
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Location = new Point(140, 184);
            label9.Name = "label9";
            label9.Size = new Size(25, 20);
            label9.TabIndex = 15;
            label9.Text = "10";
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Location = new Point(16, 301);
            label8.Name = "label8";
            label8.Size = new Size(71, 20);
            label8.TabIndex = 14;
            label8.Text = "Furniture ";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Location = new Point(16, 260);
            label7.Name = "label7";
            label7.Size = new Size(85, 20);
            label7.TabIndex = 13;
            label7.Text = "Equipment ";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(16, 224);
            label6.Name = "label6";
            label6.Size = new Size(80, 20);
            label6.TabIndex = 12;
            label6.Text = "Grooming ";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(16, 184);
            label5.Name = "label5";
            label5.Size = new Size(52, 20);
            label5.TabIndex = 11;
            label5.Text = "Drugs ";
            // 
            // price
            // 
            price.AutoSize = true;
            price.Font = new Font("Sitka Subheading", 18F, FontStyle.Bold, GraphicsUnit.Point);
            price.ForeColor = Color.FromArgb(0, 0, 192);
            price.Location = new Point(16, 117);
            price.Name = "price";
            price.Size = new Size(150, 43);
            price.TabIndex = 2;
            price.Text = "Price List";
            // 
            // panel2
            // 
            panel2.BackColor = Color.LightSteelBlue;
            panel2.Location = new Point(208, 3);
            panel2.Name = "panel2";
            panel2.Size = new Size(566, 111);
            panel2.TabIndex = 1;
            // 
            // pictureBox1
            // 
            pictureBox1.Image = (Image)resources.GetObject("pictureBox1.Image");
            pictureBox1.Location = new Point(1, 0);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(204, 111);
            pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox1.TabIndex = 1;
            pictureBox1.TabStop = false;
            // 
            // panel3
            // 
            panel3.BackColor = SystemColors.ActiveCaption;
            panel3.Controls.Add(label14);
            panel3.Controls.Add(label13);
            panel3.Controls.Add(pictureBox1);
            panel3.Location = new Point(-1, 0);
            panel3.Name = "panel3";
            panel3.Size = new Size(816, 111);
            panel3.TabIndex = 1;
            // 
            // label14
            // 
            label14.AutoSize = true;
            label14.Location = new Point(484, 33);
            label14.Name = "label14";
            label14.Size = new Size(50, 20);
            label14.TabIndex = 3;
            label14.Text = "*Sum*";
            // 
            // label13
            // 
            label13.AutoSize = true;
            label13.Location = new Point(404, 33);
            label13.Name = "label13";
            label13.Size = new Size(50, 20);
            label13.TabIndex = 2;
            label13.Text = "Funds:";
            // 
            // pictureBox2
            // 
            pictureBox2.Image = (Image)resources.GetObject("pictureBox2.Image");
            pictureBox2.Location = new Point(322, 337);
            pictureBox2.Name = "pictureBox2";
            pictureBox2.Size = new Size(138, 137);
            pictureBox2.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox2.TabIndex = 2;
            pictureBox2.TabStop = false;
            // 
            // pictureBox3
            // 
            pictureBox3.Image = (Image)resources.GetObject("pictureBox3.Image");
            pictureBox3.Location = new Point(210, 117);
            pictureBox3.Name = "pictureBox3";
            pictureBox3.Size = new Size(150, 137);
            pictureBox3.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox3.TabIndex = 3;
            pictureBox3.TabStop = false;
            // 
            // pictureBox4
            // 
            pictureBox4.Image = (Image)resources.GetObject("pictureBox4.Image");
            pictureBox4.Location = new Point(645, 117);
            pictureBox4.Name = "pictureBox4";
            pictureBox4.Size = new Size(155, 137);
            pictureBox4.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox4.TabIndex = 4;
            pictureBox4.TabStop = false;
            // 
            // pictureBox5
            // 
            pictureBox5.Image = (Image)resources.GetObject("pictureBox5.Image");
            pictureBox5.Location = new Point(545, 337);
            pictureBox5.Name = "pictureBox5";
            pictureBox5.Size = new Size(150, 137);
            pictureBox5.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox5.TabIndex = 5;
            pictureBox5.TabStop = false;
            // 
            // BuyDrugs
            // 
            BuyDrugs.BackColor = SystemColors.ActiveCaption;
            BuyDrugs.Location = new Point(366, 172);
            BuyDrugs.Name = "BuyDrugs";
            BuyDrugs.Size = new Size(94, 29);
            BuyDrugs.TabIndex = 6;
            BuyDrugs.Text = "Buy";
            BuyDrugs.UseVisualStyleBackColor = false;
            BuyDrugs.Click += BuyDrugs_Click;
            // 
            // BuyEquipment
            // 
            BuyEquipment.BackColor = SystemColors.ActiveCaption;
            BuyEquipment.Location = new Point(341, 480);
            BuyEquipment.Name = "BuyEquipment";
            BuyEquipment.Size = new Size(94, 29);
            BuyEquipment.TabIndex = 7;
            BuyEquipment.Text = "Buy";
            BuyEquipment.UseVisualStyleBackColor = false;
            BuyEquipment.Click += BuyEquipment_Click;
            // 
            // BuyGrooming
            // 
            BuyGrooming.BackColor = SystemColors.ActiveCaption;
            BuyGrooming.Location = new Point(545, 172);
            BuyGrooming.Name = "BuyGrooming";
            BuyGrooming.Size = new Size(94, 29);
            BuyGrooming.TabIndex = 8;
            BuyGrooming.Text = "Buy";
            BuyGrooming.UseVisualStyleBackColor = false;
            BuyGrooming.Click += BuyGrooming_Click;
            // 
            // BuyFurniture
            // 
            BuyFurniture.BackColor = SystemColors.ActiveCaption;
            BuyFurniture.Location = new Point(571, 480);
            BuyFurniture.Name = "BuyFurniture";
            BuyFurniture.Size = new Size(94, 29);
            BuyFurniture.TabIndex = 9;
            BuyFurniture.Text = "Buy";
            BuyFurniture.UseVisualStyleBackColor = false;
            BuyFurniture.Click += BuyFurniture_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 10.8F, FontStyle.Bold, GraphicsUnit.Point);
            label1.Location = new Point(250, 257);
            label1.Name = "label1";
            label1.Size = new Size(62, 25);
            label1.TabIndex = 10;
            label1.Text = "Drugs";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI", 10.8F, FontStyle.Bold, GraphicsUnit.Point);
            label2.Location = new Point(681, 257);
            label2.Name = "label2";
            label2.Size = new Size(97, 25);
            label2.TabIndex = 11;
            label2.Text = "Grooming";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Segoe UI", 10.8F, FontStyle.Bold, GraphicsUnit.Point);
            label3.Location = new Point(341, 309);
            label3.Name = "label3";
            label3.Size = new Size(104, 25);
            label3.TabIndex = 12;
            label3.Text = "Equipment";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Segoe UI", 10.8F, FontStyle.Bold, GraphicsUnit.Point);
            label4.Location = new Point(571, 309);
            label4.Name = "label4";
            label4.Size = new Size(95, 25);
            label4.TabIndex = 13;
            label4.Text = "Furniture ";
            // 
            // comboBoxDrugs
            // 
            comboBoxDrugs.FormattingEnabled = true;
            comboBoxDrugs.Location = new Point(366, 138);
            comboBoxDrugs.Name = "comboBoxDrugs";
            comboBoxDrugs.Size = new Size(94, 28);
            comboBoxDrugs.TabIndex = 14;
            // 
            // comboBoxGrooming
            // 
            comboBoxGrooming.FormattingEnabled = true;
            comboBoxGrooming.Location = new Point(544, 138);
            comboBoxGrooming.Name = "comboBoxGrooming";
            comboBoxGrooming.Size = new Size(95, 28);
            comboBoxGrooming.TabIndex = 15;
            // 
            // FormStore
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.ButtonHighlight;
            ClientSize = new Size(812, 571);
            Controls.Add(comboBoxGrooming);
            Controls.Add(comboBoxDrugs);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(BuyFurniture);
            Controls.Add(BuyGrooming);
            Controls.Add(BuyEquipment);
            Controls.Add(BuyDrugs);
            Controls.Add(pictureBox5);
            Controls.Add(pictureBox4);
            Controls.Add(pictureBox3);
            Controls.Add(pictureBox2);
            Controls.Add(panel3);
            Controls.Add(panel1);
            Name = "FormStore";
            Text = "FormStore";
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            panel3.ResumeLayout(false);
            panel3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox4).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox5).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Panel panel1;
        private Label label12;
        private Label label11;
        private Label label10;
        private Label label9;
        private Label label8;
        private Label label7;
        private Label label6;
        private Label label5;
        private Label price;
        private Panel panel2;
        private PictureBox pictureBox1;
        private Panel panel3;
        private PictureBox pictureBox2;
        private PictureBox pictureBox3;
        private PictureBox pictureBox4;
        private PictureBox pictureBox5;
        private Button BuyDrugs;
        private Button BuyEquipment;
        private Button BuyGrooming;
        private Button BuyFurniture;
        private Label label1;
        private Label label2;
        private Label label3;
        private Label label4;
        private ComboBox comboBoxDrugs;
        private ComboBox comboBoxGrooming;
        private Label label14;
        private Label label13;
    }
}
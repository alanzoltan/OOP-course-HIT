﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Animal
{
    public partial class StartupForm : Form
    {
        public StartupForm()
        {
            InitializeComponent();
            Seri.LoadMoney();
        }

        private void AddPatientButton_Click(object sender, EventArgs e)
        {
            FormMain form = new FormMain();
            form.ShowDialog();
        }

        private void buttonAddBird_Click(object sender, EventArgs e)
        {
            FormBird1 form = new FormBird1();
            form.ShowDialog();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            picBoxPaws.Image = new Bitmap(@"C:\Users\Polina\Desktop\2021-12-21_What_to_Expect_at_the_Emergency_Vet_Stocksy_txp63309791b5I300_Medium_2123899.jpg");
            picBoxPaws.Refresh();
            System.Threading.Thread.Sleep(2000);
            picBoxPaws.Image = new Bitmap(@"C:\Users\Polina\Desktop\077c1e70-a086-11ed-8f65-71bfa0525ce3.jpg");
            picBoxPaws.Refresh();
            System.Threading.Thread.Sleep(2000);
            picBoxPaws.Image = new Bitmap(@"C:\Users\Polina\Desktop\Veterinarian-Best-Wallpaper.jpg");
            picBoxPaws.Refresh();
            System.Threading.Thread.Sleep(2000);
            picBoxPaws.Image = new Bitmap(@"C:\Users\Polina\Desktop\maxresdefault.jpg");
            picBoxPaws.Refresh();
            System.Threading.Thread.Sleep(2000);
            picBoxPaws.Image = new Bitmap(@"C:\Users\Polina\Desktop\my-cat-at-the-vet-and-the-veterinarian-just-walked-in-the-room-100__605.jpg");
            picBoxPaws.Refresh();
            System.Threading.Thread.Sleep(2000);
            picBoxPaws.Image = new Bitmap(@"C:\Users\Polina\Desktop\vet-parrot-bird-vet-african-grey-parrot-shutterstock_675958786-scaled.jpg");
            picBoxPaws.Refresh();
            System.Threading.Thread.Sleep(2000);
            picBoxPaws.Image = new Bitmap(@"C:\Users\Polina\Desktop\הורדה (1).jpg");
            picBoxPaws.Refresh();
            System.Threading.Thread.Sleep(2000);
            picBoxPaws.Image = new Bitmap(@"C:\Users\Polina\Desktop\beagle-pup-chewing-on-bone-royalty-free-image-1655413044.jpg");
            picBoxPaws.Refresh();
            System.Threading.Thread.Sleep(2000);
        }

        private void buttonPawPharm_Click(object sender, EventArgs e)
        {
            FormStore form = new FormStore();
            form.ShowDialog();
        }

        private void buttonTreatments_Click(object sender, EventArgs e)
        {
            FormSurgeries form = new FormSurgeries();
            form.ShowDialog();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            FormRecommendations form = new FormRecommendations();
            form.ShowDialog();
        }
    }
}

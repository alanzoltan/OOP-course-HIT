﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Animal
{
    public partial class AddCat : UserControl
    {
        private BindingList<Cat> cats;
        public AddCat(BindingList<Cat> cats)
        {
            InitializeComponent();
            comboBoxFurColor.DataSource = Enum.GetValues(typeof(EnumColors));
            comboBoxBreed.DataSource = Enum.GetValues(typeof(EnumCatsBreed));
            ComboBoxSex.Items.Add("male");
            ComboBoxSex.Items.Add("female");
            this.cats = cats;
        }

        private void ClearButton_Click(object sender, EventArgs e)
        {
            ClearForm();
        }
        private void ClearForm()
        {
            NameTextBox.Clear();
            AgeTextBox.Clear();
            WeightTextBox.Clear();
            BallCheckBox.Checked = false;
            isHomeCatCheckBox.Checked = false;
            comboBoxBreed.ResetText();
            comboBoxFurColor.ResetText();
            ComboBoxSex.ResetText();
            checkBoxHasTail.Checked = false;
        }
        private bool IsValidForm()
        {
            int age;
            if (Int32.TryParse(AgeTextBox.Text, out age) != true) return false;
            return true;
        }

        private void AddButton_Click(object sender, EventArgs e)
        {
            if (IsValidForm())
            {
                string name = NameTextBox.Text;
                int age = int.Parse(AgeTextBox.Text);
                double weight = Double.Parse(WeightTextBox.Text);
                string sex = ComboBoxSex.SelectedItem.ToString();
                string furColor = comboBoxFurColor.SelectedItem.ToString();
                bool hasTail = checkBoxHasTail.Checked;
                string breed = comboBoxBreed.SelectedItem.ToString();
                bool isHomeCat = isHomeCatCheckBox.Checked;
                bool hasFurBall = BallCheckBox.Checked;
                Cat cat = new Cat(name, age, weight, sex, furColor, hasTail, breed, hasFurBall, isHomeCat);
                AnimalsManager.AddAnimal(cat);
                cats.Add(cat);
                ClearForm();
                cat.MakeSound();
                AnimalsManager.SaveAnimalsNotEvent();
            }
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using WMPLib;

namespace Animal
{
    public partial class AddDog : UserControl
    {
        private BindingList<Dog> dogs;
        public AddDog(BindingList<Dog> dogs)
        {
            InitializeComponent();
            comboBoxFurColor.DataSource = Enum.GetValues(typeof(EnumColors));
            comboBoxBreed.DataSource = Enum.GetValues(typeof(EnumBreed));
            ComboBoxSex.Items.Add("male");
            ComboBoxSex.Items.Add("female");
            this.dogs = dogs;
        }

        private void AddButton_Click(object sender, EventArgs e)
        {
            if (IsValidForm())
            {
                string name = NameTextBox.Text;
                int age = int.Parse(AgeTextBox.Text);
                double weight = Double.Parse(WeightTextBox.Text);
                string sex = ComboBoxSex.SelectedItem.ToString();
                string furColor = comboBoxFurColor.SelectedItem.ToString();
                bool hasTail = HasTailCheckBox.Checked;
                string breed = comboBoxBreed.SelectedItem.ToString();
                bool hasCollar = CollarCheckBox.Checked;
                Dog dog = new Dog(name, age, weight, sex, furColor, hasTail, breed, hasCollar);
                AnimalsManager.AddAnimal(dog);
                dogs.Add(dog);
                ClearForm();
                dog.MakeSound();
                AnimalsManager.SaveAnimalsNotEvent();
            }
        }

        private bool IsValidForm()
        {
            int age;
            if (Int32.TryParse(AgeTextBox.Text, out age) != true) return false;
            return true;
        }

        private void ClearForm()
        {
            NameTextBox.Clear();
            AgeTextBox.Clear();
            WeightTextBox.Clear();
            HasTailCheckBox.Checked = false;
            CollarCheckBox.Checked = false;
            comboBoxBreed.ResetText();
            comboBoxFurColor.ResetText();
            ComboBoxSex.ResetText();
        }

        private void ClearButton_Click(object sender, EventArgs e)
        {
            ClearForm();
        }
    }
}

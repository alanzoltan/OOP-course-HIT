﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.Json.Serialization;
using System.Threading.Tasks;

namespace Animal
{
    [Serializable]
    public abstract class Mammal : Animal
    {
        public string FurColor { get; set; }
        public bool HasTail { get; set; }
        public string Breed { get; set; }
        public int SurgeryHeart { get; set; }
        public int SurgeryBrain { get; set; }
        public int SurgeryPaws { get; set; }
        public int SurgeryFlea { get; set; }
        public int SurgeryAllergy { get; set; }
        public int SurgeryLungs { get; set; }
        protected Mammal(string name, int age, double weight, string sex, string furColor, bool hasTail, string breed)
            : base(name, age, weight, sex)
        {
            FurColor = furColor;
            HasTail = hasTail;
            Breed = breed;
            SurgeryLungs = 0;
            SurgeryHeart = 0;
            SurgeryBrain = 0;
            SurgeryPaws = 0;
            SurgeryFlea = 0;
            SurgeryAllergy = 0;
        }
        public void UpdatePayment()
        {
            int newPayment = 0;
            newPayment += SurgeryLungs * 100;
            newPayment += SurgeryHeart * 200;
            newPayment += SurgeryBrain * 300;
            newPayment += SurgeryPaws * 20;
            newPayment += SurgeryFlea * 5;
            newPayment += SurgeryAllergy * 5;
            newPayment += Subscription;
            Payment = newPayment;
        }
    }
}

﻿namespace Animal
{
    partial class FormMain
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            dataGridViewAnimal = new DataGridView();
            Kind = new Label();
            comboBoxKind = new ComboBox();
            AddAnimal = new Panel();
            buttonDelete = new Button();
            ((System.ComponentModel.ISupportInitialize)dataGridViewAnimal).BeginInit();
            SuspendLayout();
            // 
            // dataGridViewAnimal
            // 
            dataGridViewAnimal.AllowUserToAddRows = false;
            dataGridViewAnimal.BackgroundColor = SystemColors.ActiveCaption;
            dataGridViewAnimal.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewAnimal.Location = new Point(375, 56);
            dataGridViewAnimal.Name = "dataGridViewAnimal";
            dataGridViewAnimal.RowHeadersWidth = 51;
            dataGridViewAnimal.RowTemplate.Height = 29;
            dataGridViewAnimal.Size = new Size(400, 321);
            dataGridViewAnimal.TabIndex = 18;
            // 
            // Kind
            // 
            Kind.AutoSize = true;
            Kind.Location = new Point(34, 22);
            Kind.Name = "Kind";
            Kind.Size = new Size(39, 20);
            Kind.TabIndex = 19;
            Kind.Text = "Kind";
            // 
            // comboBoxKind
            // 
            comboBoxKind.FormattingEnabled = true;
            comboBoxKind.Location = new Point(141, 22);
            comboBoxKind.Name = "comboBoxKind";
            comboBoxKind.Size = new Size(151, 28);
            comboBoxKind.TabIndex = 20;
            comboBoxKind.SelectedIndexChanged += ComboBoxKind_SelectedIndexChanged;
            // 
            // AddAnimal
            // 
            AddAnimal.Location = new Point(25, 56);
            AddAnimal.Name = "AddAnimal";
            AddAnimal.Size = new Size(335, 370);
            AddAnimal.TabIndex = 22;
            // 
            // buttonDelete
            // 
            buttonDelete.BackColor = SystemColors.ActiveCaption;
            buttonDelete.Location = new Point(537, 397);
            buttonDelete.Name = "buttonDelete";
            buttonDelete.Size = new Size(94, 29);
            buttonDelete.TabIndex = 23;
            buttonDelete.Text = "Delete";
            buttonDelete.UseVisualStyleBackColor = false;
            buttonDelete.Click += buttonDelete_Click;
            // 
            // FormMain
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.ButtonHighlight;
            ClientSize = new Size(800, 450);
            Controls.Add(buttonDelete);
            Controls.Add(AddAnimal);
            Controls.Add(comboBoxKind);
            Controls.Add(Kind);
            Controls.Add(dataGridViewAnimal);
            Name = "FormMain";
            Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)dataGridViewAnimal).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private Button button1;
        private TextBox textBox3;
        private DataGridView dataGridViewAnimal;
        private Label Kind;
        private ComboBox comboBoxKind;
        private Panel AddAnimal;
        private Button buttonDelete;
    }
}
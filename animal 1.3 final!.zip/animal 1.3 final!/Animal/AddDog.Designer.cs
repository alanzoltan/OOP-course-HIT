﻿namespace Animal
{
    partial class AddDog
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            comboBoxFurColor = new ComboBox();
            comboBoxBreed = new ComboBox();
            label5 = new Label();
            label6 = new Label();
            HasTailCheckBox = new CheckBox();
            label1 = new Label();
            CollarCheckBox = new CheckBox();
            AddButton = new Button();
            WeightTextBox = new TextBox();
            label3 = new Label();
            label4 = new Label();
            AgeTextBox = new TextBox();
            NameTextBox = new TextBox();
            label2 = new Label();
            NAME = new Label();
            ClearButton = new Button();
            label8 = new Label();
            ComboBoxSex = new ComboBox();
            SuspendLayout();
            // 
            // comboBoxFurColor
            // 
            comboBoxFurColor.FormattingEnabled = true;
            comboBoxFurColor.Location = new Point(127, 225);
            comboBoxFurColor.Name = "comboBoxFurColor";
            comboBoxFurColor.Size = new Size(151, 28);
            comboBoxFurColor.TabIndex = 31;
            // 
            // comboBoxBreed
            // 
            comboBoxBreed.FormattingEnabled = true;
            comboBoxBreed.Location = new Point(127, 181);
            comboBoxBreed.Name = "comboBoxBreed";
            comboBoxBreed.Size = new Size(151, 28);
            comboBoxBreed.TabIndex = 30;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(20, 225);
            label5.Name = "label5";
            label5.Size = new Size(69, 20);
            label5.TabIndex = 29;
            label5.Text = "Fur Color";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(20, 189);
            label6.Name = "label6";
            label6.Size = new Size(48, 20);
            label6.TabIndex = 28;
            label6.Text = "Breed";
            // 
            // HasTailCheckBox
            // 
            HasTailCheckBox.AutoSize = true;
            HasTailCheckBox.Location = new Point(127, 298);
            HasTailCheckBox.Name = "HasTailCheckBox";
            HasTailCheckBox.Size = new Size(18, 17);
            HasTailCheckBox.TabIndex = 27;
            HasTailCheckBox.UseVisualStyleBackColor = true;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(20, 295);
            label1.Name = "label1";
            label1.Size = new Size(60, 20);
            label1.TabIndex = 26;
            label1.Text = "Has Tail";
            // 
            // CollarCheckBox
            // 
            CollarCheckBox.AutoSize = true;
            CollarCheckBox.Location = new Point(127, 266);
            CollarCheckBox.Name = "CollarCheckBox";
            CollarCheckBox.Size = new Size(18, 17);
            CollarCheckBox.TabIndex = 25;
            CollarCheckBox.UseVisualStyleBackColor = true;
            // 
            // AddButton
            // 
            AddButton.BackColor = SystemColors.ActiveCaption;
            AddButton.Location = new Point(59, 335);
            AddButton.Name = "AddButton";
            AddButton.Size = new Size(94, 29);
            AddButton.TabIndex = 24;
            AddButton.Text = "Add";
            AddButton.UseVisualStyleBackColor = false;
            AddButton.Click += AddButton_Click;
            // 
            // WeightTextBox
            // 
            WeightTextBox.Location = new Point(127, 101);
            WeightTextBox.Name = "WeightTextBox";
            WeightTextBox.Size = new Size(125, 27);
            WeightTextBox.TabIndex = 23;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(20, 263);
            label3.Name = "label3";
            label3.Size = new Size(77, 20);
            label3.TabIndex = 22;
            label3.Text = "Has Collar";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(20, 101);
            label4.Name = "label4";
            label4.Size = new Size(56, 20);
            label4.TabIndex = 21;
            label4.Text = "Weight";
            // 
            // AgeTextBox
            // 
            AgeTextBox.Location = new Point(127, 64);
            AgeTextBox.Name = "AgeTextBox";
            AgeTextBox.Size = new Size(125, 27);
            AgeTextBox.TabIndex = 20;
            // 
            // NameTextBox
            // 
            NameTextBox.Location = new Point(127, 28);
            NameTextBox.Name = "NameTextBox";
            NameTextBox.Size = new Size(125, 27);
            NameTextBox.TabIndex = 19;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(20, 64);
            label2.Name = "label2";
            label2.Size = new Size(36, 20);
            label2.TabIndex = 18;
            label2.Text = "Age";
            // 
            // NAME
            // 
            NAME.AutoSize = true;
            NAME.Location = new Point(20, 28);
            NAME.Name = "NAME";
            NAME.Size = new Size(49, 20);
            NAME.TabIndex = 17;
            NAME.Text = "Name";
            // 
            // ClearButton
            // 
            ClearButton.BackColor = SystemColors.ActiveCaption;
            ClearButton.Location = new Point(210, 335);
            ClearButton.Name = "ClearButton";
            ClearButton.Size = new Size(94, 29);
            ClearButton.TabIndex = 32;
            ClearButton.Text = "Clear";
            ClearButton.UseVisualStyleBackColor = false;
            ClearButton.Click += ClearButton_Click;
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Location = new Point(20, 145);
            label8.Name = "label8";
            label8.Size = new Size(32, 20);
            label8.TabIndex = 34;
            label8.Text = "Sex";
            // 
            // ComboBoxSex
            // 
            ComboBoxSex.FormattingEnabled = true;
            ComboBoxSex.Location = new Point(127, 142);
            ComboBoxSex.Name = "ComboBoxSex";
            ComboBoxSex.Size = new Size(151, 28);
            ComboBoxSex.TabIndex = 35;
            // 
            // AddDog
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            Controls.Add(ComboBoxSex);
            Controls.Add(label8);
            Controls.Add(ClearButton);
            Controls.Add(comboBoxFurColor);
            Controls.Add(comboBoxBreed);
            Controls.Add(label5);
            Controls.Add(label6);
            Controls.Add(HasTailCheckBox);
            Controls.Add(label1);
            Controls.Add(CollarCheckBox);
            Controls.Add(AddButton);
            Controls.Add(WeightTextBox);
            Controls.Add(label3);
            Controls.Add(label4);
            Controls.Add(AgeTextBox);
            Controls.Add(NameTextBox);
            Controls.Add(label2);
            Controls.Add(NAME);
            Name = "AddDog";
            Size = new Size(405, 433);
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private ComboBox comboBoxFurColor;
        private ComboBox comboBoxBreed;
        private Label label5;
        private Label label6;
        private CheckBox HasTailCheckBox;
        private Label label1;
        private CheckBox CollarCheckBox;
        private Button AddButton;
        private TextBox WeightTextBox;
        private Label label3;
        private Label label4;
        private TextBox AgeTextBox;
        private TextBox NameTextBox;
        private Label label2;
        private Label NAME;
        private Button ClearButton;
        private Label label8;
        private ComboBox ComboBoxSex;
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Media;
using System.Text;
using System.Threading.Tasks;
using WMPLib;

namespace Animal
{
    [Serializable]
    public class Bird : Animal
    {
        public bool Homebird { get; set; }
        public bool CutWings { get; set; }
        public string Color { get; set; }
        public string Breed { get; set; }

        public Bird(string name, int age, double weight, string sex, bool homebird, bool cutWings, string color, string breed)
            : base(name, age, weight, sex)
        {
            Homebird = homebird;
            CutWings = cutWings;
            Color = color;
            Breed = breed;
            Subscription = 5;
        }
        public override void MakeSound()
        {
            SoundPlayer s = new SoundPlayer(@"C:\temp\animal 1.3 final!\Animal\bin\Debug\net6.0-windows\mixkit-forest-birds-singing-1212.wav");
            s.Play();
        }
    }
}

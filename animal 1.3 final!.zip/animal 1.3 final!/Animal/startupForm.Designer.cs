﻿namespace Animal
{
    partial class StartupForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(StartupForm));
            panel1 = new Panel();
            button2 = new Button();
            buttonTreatments = new Button();
            buttonPawPharm = new Button();
            AddPatientButton = new Button();
            buttonAddBird = new Button();
            pictureBox1 = new PictureBox();
            button1 = new Button();
            picBoxPaws = new PictureBox();
            pictureBox3 = new PictureBox();
            panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)picBoxPaws).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).BeginInit();
            SuspendLayout();
            // 
            // panel1
            // 
            panel1.BackColor = Color.PowderBlue;
            panel1.Controls.Add(button2);
            panel1.Controls.Add(buttonTreatments);
            panel1.Controls.Add(buttonPawPharm);
            panel1.Controls.Add(AddPatientButton);
            panel1.Controls.Add(buttonAddBird);
            panel1.Controls.Add(pictureBox1);
            panel1.Location = new Point(-2, -2);
            panel1.Name = "panel1";
            panel1.Size = new Size(259, 622);
            panel1.TabIndex = 1;
            // 
            // button2
            // 
            button2.BackColor = Color.DarkCyan;
            button2.Location = new Point(0, 457);
            button2.Name = "button2";
            button2.Size = new Size(259, 29);
            button2.TabIndex = 8;
            button2.Text = "Recommendations";
            button2.UseVisualStyleBackColor = false;
            button2.Click += button2_Click;
            // 
            // buttonTreatments
            // 
            buttonTreatments.BackColor = Color.DarkCyan;
            buttonTreatments.Location = new Point(1, 406);
            buttonTreatments.Name = "buttonTreatments";
            buttonTreatments.Size = new Size(259, 29);
            buttonTreatments.TabIndex = 7;
            buttonTreatments.Text = "Treatments";
            buttonTreatments.UseVisualStyleBackColor = false;
            buttonTreatments.Click += buttonTreatments_Click;
            // 
            // buttonPawPharm
            // 
            buttonPawPharm.BackColor = Color.DarkCyan;
            buttonPawPharm.Location = new Point(0, 355);
            buttonPawPharm.Name = "buttonPawPharm";
            buttonPawPharm.Size = new Size(259, 29);
            buttonPawPharm.TabIndex = 6;
            buttonPawPharm.Text = "PawPharm";
            buttonPawPharm.UseVisualStyleBackColor = false;
            buttonPawPharm.Click += buttonPawPharm_Click;
            // 
            // AddPatientButton
            // 
            AddPatientButton.BackColor = Color.DarkCyan;
            AddPatientButton.Location = new Point(0, 246);
            AddPatientButton.Name = "AddPatientButton";
            AddPatientButton.Size = new Size(259, 29);
            AddPatientButton.TabIndex = 5;
            AddPatientButton.Text = "Manage Mammals";
            AddPatientButton.UseVisualStyleBackColor = false;
            AddPatientButton.Click += AddPatientButton_Click;
            // 
            // buttonAddBird
            // 
            buttonAddBird.BackColor = Color.DarkCyan;
            buttonAddBird.Location = new Point(0, 301);
            buttonAddBird.Name = "buttonAddBird";
            buttonAddBird.Size = new Size(259, 29);
            buttonAddBird.TabIndex = 1;
            buttonAddBird.Text = "Manage Birds";
            buttonAddBird.UseVisualStyleBackColor = false;
            buttonAddBird.Click += buttonAddBird_Click;
            // 
            // pictureBox1
            // 
            pictureBox1.Image = (Image)resources.GetObject("pictureBox1.Image");
            pictureBox1.Location = new Point(1, 3);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(258, 176);
            pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox1.TabIndex = 1;
            pictureBox1.TabStop = false;
            // 
            // button1
            // 
            button1.BackColor = SystemColors.ActiveCaption;
            button1.Location = new Point(444, 353);
            button1.Name = "button1";
            button1.Size = new Size(162, 29);
            button1.TabIndex = 3;
            button1.Text = "Our Happy Paws";
            button1.UseVisualStyleBackColor = false;
            button1.Click += button1_Click;
            // 
            // picBoxPaws
            // 
            picBoxPaws.Location = new Point(365, 43);
            picBoxPaws.Name = "picBoxPaws";
            picBoxPaws.Size = new Size(318, 285);
            picBoxPaws.SizeMode = PictureBoxSizeMode.StretchImage;
            picBoxPaws.TabIndex = 4;
            picBoxPaws.TabStop = false;
            // 
            // pictureBox3
            // 
            pictureBox3.Image = (Image)resources.GetObject("pictureBox3.Image");
            pictureBox3.Location = new Point(595, 449);
            pictureBox3.Name = "pictureBox3";
            pictureBox3.Size = new Size(200, 160);
            pictureBox3.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox3.TabIndex = 5;
            pictureBox3.TabStop = false;
            // 
            // StartupForm
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.ButtonHighlight;
            ClientSize = new Size(807, 621);
            Controls.Add(pictureBox3);
            Controls.Add(picBoxPaws);
            Controls.Add(button1);
            Controls.Add(panel1);
            Name = "StartupForm";
            Text = "startupForm";
            panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ((System.ComponentModel.ISupportInitialize)picBoxPaws).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private Panel panel1;
        private Button AddPatientButton;
        private Button buttonAddBird;
        private PictureBox pictureBox1;
        private Button button1;
        private PictureBox picBoxPaws;
        private PictureBox pictureBox3;
        private Button buttonTreatments;
        private Button buttonPawPharm;
        private Button button2;
    }
}
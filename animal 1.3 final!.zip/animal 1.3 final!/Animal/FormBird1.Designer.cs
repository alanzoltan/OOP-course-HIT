﻿namespace Animal
{
    partial class FormBird1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            comboBoxColor = new ComboBox();
            comboBoxBreed = new ComboBox();
            comboBoxSex = new ComboBox();
            textBoxWeight = new TextBox();
            textBoxAge = new TextBox();
            textBoxName = new TextBox();
            buttonClear = new Button();
            buttonAdd = new Button();
            checkBoxCutWings = new CheckBox();
            checkBoxHomebird = new CheckBox();
            label6 = new Label();
            label5 = new Label();
            label4 = new Label();
            label3 = new Label();
            label2 = new Label();
            label1 = new Label();
            label7 = new Label();
            dataGridView1 = new DataGridView();
            buttonDelete = new Button();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
            SuspendLayout();
            // 
            // comboBoxColor
            // 
            comboBoxColor.FormattingEnabled = true;
            comboBoxColor.Location = new Point(124, 286);
            comboBoxColor.Name = "comboBoxColor";
            comboBoxColor.Size = new Size(151, 28);
            comboBoxColor.TabIndex = 91;
            // 
            // comboBoxBreed
            // 
            comboBoxBreed.FormattingEnabled = true;
            comboBoxBreed.Location = new Point(124, 240);
            comboBoxBreed.Name = "comboBoxBreed";
            comboBoxBreed.Size = new Size(151, 28);
            comboBoxBreed.TabIndex = 90;
            // 
            // comboBoxSex
            // 
            comboBoxSex.FormattingEnabled = true;
            comboBoxSex.Location = new Point(124, 196);
            comboBoxSex.Name = "comboBoxSex";
            comboBoxSex.Size = new Size(151, 28);
            comboBoxSex.TabIndex = 89;
            // 
            // textBoxWeight
            // 
            textBoxWeight.Location = new Point(124, 150);
            textBoxWeight.Name = "textBoxWeight";
            textBoxWeight.Size = new Size(125, 27);
            textBoxWeight.TabIndex = 88;
            // 
            // textBoxAge
            // 
            textBoxAge.Location = new Point(124, 102);
            textBoxAge.Name = "textBoxAge";
            textBoxAge.Size = new Size(125, 27);
            textBoxAge.TabIndex = 87;
            // 
            // textBoxName
            // 
            textBoxName.Location = new Point(124, 58);
            textBoxName.Name = "textBoxName";
            textBoxName.Size = new Size(125, 27);
            textBoxName.TabIndex = 86;
            // 
            // buttonClear
            // 
            buttonClear.BackColor = SystemColors.ActiveCaption;
            buttonClear.Location = new Point(248, 392);
            buttonClear.Name = "buttonClear";
            buttonClear.Size = new Size(94, 29);
            buttonClear.TabIndex = 85;
            buttonClear.Text = "Clear";
            buttonClear.UseVisualStyleBackColor = false;
            buttonClear.Click += buttonClear_Click;
            // 
            // buttonAdd
            // 
            buttonAdd.BackColor = SystemColors.ActiveCaption;
            buttonAdd.Location = new Point(84, 393);
            buttonAdd.Name = "buttonAdd";
            buttonAdd.Size = new Size(94, 29);
            buttonAdd.TabIndex = 84;
            buttonAdd.Text = "Add";
            buttonAdd.UseVisualStyleBackColor = false;
            buttonAdd.Click += buttonAdd_Click;
            // 
            // checkBoxCutWings
            // 
            checkBoxCutWings.AutoSize = true;
            checkBoxCutWings.Location = new Point(213, 335);
            checkBoxCutWings.Name = "checkBoxCutWings";
            checkBoxCutWings.Size = new Size(98, 24);
            checkBoxCutWings.TabIndex = 83;
            checkBoxCutWings.Text = "Cut Wings";
            checkBoxCutWings.UseVisualStyleBackColor = true;
            // 
            // checkBoxHomebird
            // 
            checkBoxHomebird.AutoSize = true;
            checkBoxHomebird.Location = new Point(48, 335);
            checkBoxHomebird.Name = "checkBoxHomebird";
            checkBoxHomebird.Size = new Size(99, 24);
            checkBoxHomebird.TabIndex = 82;
            checkBoxHomebird.Text = "Homebird";
            checkBoxHomebird.UseVisualStyleBackColor = true;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(18, 243);
            label6.Name = "label6";
            label6.Size = new Size(48, 20);
            label6.TabIndex = 81;
            label6.Text = "Breed";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(18, 289);
            label5.Name = "label5";
            label5.Size = new Size(45, 20);
            label5.TabIndex = 80;
            label5.Text = "Color";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(18, 199);
            label4.Name = "label4";
            label4.Size = new Size(32, 20);
            label4.TabIndex = 79;
            label4.Text = "Sex";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(18, 153);
            label3.Name = "label3";
            label3.Size = new Size(56, 20);
            label3.TabIndex = 78;
            label3.Text = "Weight";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(18, 109);
            label2.Name = "label2";
            label2.Size = new Size(36, 20);
            label2.TabIndex = 77;
            label2.Text = "Age";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(18, 61);
            label1.Name = "label1";
            label1.Size = new Size(49, 20);
            label1.TabIndex = 76;
            label1.Text = "Name";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Location = new Point(158, 29);
            label7.Name = "label7";
            label7.Size = new Size(42, 20);
            label7.TabIndex = 75;
            label7.Text = "Birds";
            // 
            // dataGridView1
            // 
            dataGridView1.BackgroundColor = SystemColors.ActiveCaption;
            dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView1.Location = new Point(404, 29);
            dataGridView1.Name = "dataGridView1";
            dataGridView1.RowHeadersWidth = 51;
            dataGridView1.RowTemplate.Height = 29;
            dataGridView1.Size = new Size(379, 330);
            dataGridView1.TabIndex = 74;
            // 
            // buttonDelete
            // 
            buttonDelete.BackColor = SystemColors.ActiveCaption;
            buttonDelete.Location = new Point(549, 390);
            buttonDelete.Name = "buttonDelete";
            buttonDelete.Size = new Size(94, 29);
            buttonDelete.TabIndex = 73;
            buttonDelete.Text = "Delete";
            buttonDelete.UseVisualStyleBackColor = false;
            buttonDelete.Click += buttonDelete_Click;
            // 
            // FormBird1
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.ButtonHighlight;
            ClientSize = new Size(800, 450);
            Controls.Add(comboBoxColor);
            Controls.Add(comboBoxBreed);
            Controls.Add(comboBoxSex);
            Controls.Add(textBoxWeight);
            Controls.Add(textBoxAge);
            Controls.Add(textBoxName);
            Controls.Add(buttonClear);
            Controls.Add(buttonAdd);
            Controls.Add(checkBoxCutWings);
            Controls.Add(checkBoxHomebird);
            Controls.Add(label6);
            Controls.Add(label5);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(label7);
            Controls.Add(dataGridView1);
            Controls.Add(buttonDelete);
            Name = "FormBird1";
            Text = "FormBird1";
            ((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private ComboBox comboBoxColor;
        private ComboBox comboBoxBreed;
        private ComboBox comboBoxSex;
        private TextBox textBoxWeight;
        private TextBox textBoxAge;
        private TextBox textBoxName;
        private Button buttonClear;
        private Button buttonAdd;
        private CheckBox checkBoxCutWings;
        private CheckBox checkBoxHomebird;
        private Label label6;
        private Label label5;
        private Label label4;
        private Label label3;
        private Label label2;
        private Label label1;
        private Label label7;
        private DataGridView dataGridView1;
        private Button buttonDelete;
    }
}
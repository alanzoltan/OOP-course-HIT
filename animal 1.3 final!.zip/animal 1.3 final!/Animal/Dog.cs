﻿using System;
using System.Collections.Generic;
using System.Drawing.Drawing2D;
using System.Linq;
using System.Media;
using System.Text;
using System.Threading.Tasks;
using WMPLib;

namespace Animal
{
    [Serializable]
    public class Dog:Mammal
    {
        public bool HasFleaCollar { get; set; }

        public Dog(string name, int age, double weight,string sex, string furColor, bool hasTail, string breed, bool hasFleaCollar)
            :base(name, age, weight, sex, furColor, hasTail, breed)
        {
            HasFleaCollar = hasFleaCollar;
            Subscription = 20;
        }
        public override void MakeSound()
        {
            SoundPlayer s = new SoundPlayer(@"C:\temp\animal 1.3 final!\Animal\bin\Debug\net6.0-windows\mixkit-happy-puppy-barks-741.wav");
            s.Play();
        }
    }
}

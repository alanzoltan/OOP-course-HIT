﻿namespace Animal
{
    partial class MessageBoxSurgery
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            ButtonSelect = new Button();
            label1 = new Label();
            ButtonHeart = new RadioButton();
            ButtonBrain = new RadioButton();
            ButtonFleas = new RadioButton();
            ButtonAllergy = new RadioButton();
            ButtonLungs = new RadioButton();
            ButtonPaws = new RadioButton();
            groupBox1 = new GroupBox();
            groupBox1.SuspendLayout();
            SuspendLayout();
            // 
            // ButtonSelect
            // 
            ButtonSelect.BackColor = SystemColors.ActiveCaption;
            ButtonSelect.Location = new Point(156, 157);
            ButtonSelect.Name = "ButtonSelect";
            ButtonSelect.Size = new Size(94, 29);
            ButtonSelect.TabIndex = 12;
            ButtonSelect.Text = "Select";
            ButtonSelect.UseVisualStyleBackColor = false;
            ButtonSelect.Click += ButtonSelect_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(125, 24);
            label1.Name = "label1";
            label1.Size = new Size(159, 20);
            label1.TabIndex = 13;
            label1.Text = "Which kind of surgery?";
            // 
            // ButtonHeart
            // 
            ButtonHeart.AutoSize = true;
            ButtonHeart.Location = new Point(256, 19);
            ButtonHeart.Name = "ButtonHeart";
            ButtonHeart.Size = new Size(67, 24);
            ButtonHeart.TabIndex = 6;
            ButtonHeart.TabStop = true;
            ButtonHeart.Text = "Heart";
            ButtonHeart.UseVisualStyleBackColor = true;
            // 
            // ButtonBrain
            // 
            ButtonBrain.AutoSize = true;
            ButtonBrain.Location = new Point(133, 19);
            ButtonBrain.Name = "ButtonBrain";
            ButtonBrain.Size = new Size(64, 24);
            ButtonBrain.TabIndex = 7;
            ButtonBrain.TabStop = true;
            ButtonBrain.Text = "Brain";
            ButtonBrain.UseVisualStyleBackColor = true;
            // 
            // ButtonFleas
            // 
            ButtonFleas.AutoSize = true;
            ButtonFleas.Location = new Point(10, 19);
            ButtonFleas.Name = "ButtonFleas";
            ButtonFleas.Size = new Size(63, 24);
            ButtonFleas.TabIndex = 8;
            ButtonFleas.TabStop = true;
            ButtonFleas.Text = "Fleas";
            ButtonFleas.UseVisualStyleBackColor = true;
            // 
            // ButtonAllergy
            // 
            ButtonAllergy.AutoSize = true;
            ButtonAllergy.Location = new Point(256, 69);
            ButtonAllergy.Name = "ButtonAllergy";
            ButtonAllergy.Size = new Size(77, 24);
            ButtonAllergy.TabIndex = 9;
            ButtonAllergy.TabStop = true;
            ButtonAllergy.Text = "Allergy";
            ButtonAllergy.UseVisualStyleBackColor = true;
            // 
            // ButtonLungs
            // 
            ButtonLungs.AutoSize = true;
            ButtonLungs.Location = new Point(133, 69);
            ButtonLungs.Name = "ButtonLungs";
            ButtonLungs.Size = new Size(68, 24);
            ButtonLungs.TabIndex = 10;
            ButtonLungs.TabStop = true;
            ButtonLungs.Text = "Lungs";
            ButtonLungs.UseVisualStyleBackColor = true;
            // 
            // ButtonPaws
            // 
            ButtonPaws.AutoSize = true;
            ButtonPaws.Location = new Point(10, 69);
            ButtonPaws.Name = "ButtonPaws";
            ButtonPaws.Size = new Size(62, 24);
            ButtonPaws.TabIndex = 11;
            ButtonPaws.TabStop = true;
            ButtonPaws.Text = "Paws";
            ButtonPaws.UseVisualStyleBackColor = true;
            // 
            // groupBox1
            // 
            groupBox1.Controls.Add(ButtonPaws);
            groupBox1.Controls.Add(ButtonLungs);
            groupBox1.Controls.Add(ButtonAllergy);
            groupBox1.Controls.Add(ButtonFleas);
            groupBox1.Controls.Add(ButtonBrain);
            groupBox1.Controls.Add(ButtonHeart);
            groupBox1.Location = new Point(23, 42);
            groupBox1.Name = "groupBox1";
            groupBox1.Size = new Size(349, 99);
            groupBox1.TabIndex = 14;
            groupBox1.TabStop = false;
            // 
            // MessageBoxSurgery
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.ButtonHighlight;
            ClientSize = new Size(412, 207);
            Controls.Add(groupBox1);
            Controls.Add(label1);
            Controls.Add(ButtonSelect);
            FormBorderStyle = FormBorderStyle.FixedDialog;
            Name = "MessageBoxSurgery";
            Text = "MessageBoxSurgery";
            groupBox1.ResumeLayout(false);
            groupBox1.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private Button ButtonSelect;
        private Label label1;
        private RadioButton ButtonHeart;
        private RadioButton ButtonBrain;
        private RadioButton ButtonFleas;
        private RadioButton ButtonAllergy;
        private RadioButton ButtonLungs;
        private RadioButton ButtonPaws;
        private GroupBox groupBox1;
    }
}
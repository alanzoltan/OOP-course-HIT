﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Animal
{
    public enum EnumSurgeries
    {
        Heart,
        Lungs,
        Paws,
        Allergy,
        Brain,
        Fleas
    }
}

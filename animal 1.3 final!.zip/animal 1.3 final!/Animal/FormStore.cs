﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace Animal
{
    public partial class FormStore : Form
    {
        public FormStore()
        {
            InitializeComponent();
            comboBoxDrugs.Items.Add("1");
            comboBoxDrugs.Items.Add("2");
            comboBoxDrugs.Items.Add("3");
            comboBoxGrooming.Items.Add("1");
            comboBoxGrooming.Items.Add("2");
            comboBoxGrooming.Items.Add("3");
            label14.Text = Animal.allMoney.ToString();
        }

        private void BuyFurniture_Click(object sender, EventArgs e)
        {
            if (Animal.allMoney >= 500)
            {
                Animal.allMoney -= 500;
                MessageBox.Show("Congratulations!\nNow you have new furniture");
                label14.Text = Animal.allMoney.ToString();
                Seri.SaveMoney();
            }
            else
            {
                MessageBox.Show("You have insufficient funds");
            }
        }

        private void BuyDrugs_Click(object sender, EventArgs e)
        {
            int price;
            Int32.TryParse(comboBoxDrugs.Text, out price);
            price *= 10;
            if (Animal.allMoney >= price)
            {
                Animal.allMoney -= price;
                MessageBox.Show("Congratulations!\nNow you have new drugs");
                label14.Text = Animal.allMoney.ToString();

                Seri.SaveMoney();
            }
            else
            {

                MessageBox.Show("You have insufficient funds");
            }
        }

        private void BuyGrooming_Click(object sender, EventArgs e)
        {
            int price;
            Int32.TryParse(comboBoxDrugs.Text, out price);
            price *= 15;
            if (Animal.allMoney >= price)
            {
                Animal.allMoney -= price;
                MessageBox.Show("Congratulations!\nNow you have a new grooming");
                label14.Text = Animal.allMoney.ToString();
                Seri.SaveMoney();
            }
            else
            {

                MessageBox.Show("You have insufficient funds");
            }
        }

        private void BuyEquipment_Click(object sender, EventArgs e)
        {
            if (Animal.allMoney >= 20)
            {
                Animal.allMoney -= 20;
                MessageBox.Show("Congratulations!\nNow you have new equipment");
                label14.Text = Animal.allMoney.ToString();
                Seri.SaveMoney();
            }
            else
            {

                MessageBox.Show("You have insufficient funds");
            }
        }
    }
}
